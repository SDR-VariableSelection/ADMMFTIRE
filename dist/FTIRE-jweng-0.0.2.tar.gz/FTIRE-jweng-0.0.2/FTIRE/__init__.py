#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 23 15:59:09 2021

@author: jiayingweng
"""
__all__ = ["ftire","FT3","SIR2","genxy","SpCov"]
